# basic ISO image file layout samples

This covers the basic files needed by mkmedia to create bootable ISO images.

Files generally have dummy content but for config files, initrd, and installation system / live root images.

Initrd is a valid xz compressed cpio archive (with one dummy file as content).

Installation system / live root images are squashfs images with one dummy file.

This is just enough so mkmedia can create a valid ISO image and --boot, --initrd, and --instsys options can be tested.

The created ISO image is *not* bootable, however, since no real bootloader binaries are included. It just looks as if.
