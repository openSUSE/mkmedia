# isolinux.bin

isolinux.bin fragment, need for Legacy BIOS El-Torito boot from DVD.

# eltorito.img

grub (cdboot) fragment, need for Legacy BIOS El-Torito boot from DVD.

# initrd

(Almost) empty sample initrd, xz-compressed.

# initrd_live

(Almost) empty sample initrd, xz-compressed.
In addition to 'initrd' contains /etc/cmdline.d/10-liveroot.conf, setting live root.

# kernel_s390x

Linux kernel for s390x. Has to have a minimum size of > 64 kiB.

# root

(Almost) empty sample root (installation system). A squashfs image.

# root_live

(Almost) empty sample live root. A squashfs image containing an ext4 image 'LiveOS/rootfs.img'.

# root vs. root_live

- suse yast install		root
- suse agama install		root_live
- suse live			root_live
- suse kiwi selfinstall		squashfs of a partioned disk
- sll 8.0-9.6			root_live
- rhel 8.0-8.4?			root_live
- rhel stream 10.0		root
- fedora install		root
- fedora live			root
- debian install		?
- debian live			root
